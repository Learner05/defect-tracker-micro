package com.infosys.defectmicroservice.presentation;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.defectmicroservice.service.DefectService;

@RestController
public class DefectRestController {
	
	@Autowired
	private DefectService defectService;

	// Add a Defect
	//@RequestMapping(value = "/employees", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/defects")
	public ResponseEntity<DefectTO> createDefect(@RequestBody DefectTO defect) {
		System.out.println("Received Request from Prankul");	
		defect = defectService.addDefect(defect);

		return new ResponseEntity<DefectTO>(defect, HttpStatus.OK);
	}
	
	//List all Defects
	//@RequestMapping(value = "/employees", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		@GetMapping("/defects")
		public List<DefectTO> getemployees() {
			return defectService.getAllDefects();
	} 
		
	
	@PutMapping("/defects/{id}")
		public ResponseEntity<DefectTO> closeDefect(@PathVariable("id") int dId) {

			DefectTO defect = defectService.closeDefect(dId);

			return new ResponseEntity<DefectTO>(defect, HttpStatus.OK);
			}
			
		
	
	
}
