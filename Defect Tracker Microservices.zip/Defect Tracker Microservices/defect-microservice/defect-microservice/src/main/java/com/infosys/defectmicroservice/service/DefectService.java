package com.infosys.defectmicroservice.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.defectmicroservice.entity.Defect;
import com.infosys.defectmicroservice.presentation.DefectTO;
import com.infosys.defectmicroservice.repository.IDefectRepo;



@Service
public class DefectService {
	
	@Autowired
	private IDefectRepo repository;
	
	public DefectTO addDefect(DefectTO def){
		Defect defEntity=new Defect();
		defEntity.setdCategory(def.getdCategory());
		defEntity.setdDescp(def.getdDescp());
		defEntity.setdPriority(def.getdPriority());
		defEntity.setdStatus(def.getdStatus());
		repository.saveAndFlush(defEntity);
	//	defect.addDefect(defEntity);
		def.setdId(defEntity.getdId());
		return def;
	}
	
	public List<DefectTO> getAllDefects(){
		List<DefectTO> defectTOList=new ArrayList<DefectTO>();
		//List<Defect> entityList= defect.getAllDefects();
		
		List<Defect> entityList = repository.findAll();
		Iterator<Defect> i=entityList.iterator();
		while(i.hasNext()){
			Defect entity=i.next();
			DefectTO dto=new DefectTO();
			dto.setdId(entity.getdId());
			dto.setdCategory(entity.getdCategory());
			dto.setdDescp(entity.getdDescp());
			dto.setdPriority(entity.getdPriority());
			dto.setdStatus(entity.getdStatus());
			defectTOList.add(dto);
		}
		return defectTOList;
	}
	
	public DefectTO closeDefect(int dId){
		DefectTO def= new DefectTO();
		
		// Find that specific defect before deleting it
		Defect d = repository.findOne(dId);
		{
			if (d != null) {
				d.setdStatus("closed");
				repository.saveAndFlush(d);
			} else {
				System.out.println("No Defect Found with ID: " + dId);
			}
		}
		
		//Defect d = defect.closeDefect(dId);
		def.setdId(d.getdId());
		def.setdCategory(d.getdCategory());
		def.setdDescp(d.getdDescp());
		def.setdPriority(d.getdPriority());
		def.setdStatus(d.getdStatus());
		return def;
	};	

}
