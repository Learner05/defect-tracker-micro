package com.infosys.defectmicroservice.presentation;



public class DefectTO {
	private int dId;
	
	private String dCategory;
	private String dDescp;
	private int dPriority;
	private String dStatus;
	
	
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getdCategory() {
		return dCategory;
	}
	public void setdCategory(String dCategory) {
		this.dCategory = dCategory;
	}
	public String getdDescp() {
		return dDescp;
	}
	public void setdDescp(String dDescp) {
		this.dDescp = dDescp;
	}
	public int getdPriority() {
		return dPriority;
	}
	public void setdPriority(int dPriority) {
		this.dPriority = dPriority;
	}
	public String getdStatus() {
		return dStatus;
	}
	public void setdStatus(String dStatus) {
		this.dStatus = dStatus;
	}
	
	@Override
	public String toString() {
		return "DefectTO [dId=" + dId + ", dCategory=" + dCategory + ", dDescp=" + dDescp + ", dPriority=" + dPriority
				+ ", dStatus=" + dStatus + "]";
	}
		
}
