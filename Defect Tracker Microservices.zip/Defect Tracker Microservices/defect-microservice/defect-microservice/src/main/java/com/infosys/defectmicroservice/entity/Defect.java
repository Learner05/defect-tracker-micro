package com.infosys.defectmicroservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Defect_Table")
@GenericGenerator(name = "idgen", strategy = "increment")
public class Defect {
	
	@Id
	@GeneratedValue(generator = "idgen")
	@Column(name="did")
	private int dId;
	
	@Column(name="dcategory")
	private String dCategory;
	
	@Column(name="ddescp")
	private String dDescp;
	
	@Column(name="dproiority")
	private int dPriority;
	
	@Column(name="dstatus")
	private String dStatus;
	
	public Defect() {
		
	}
	
	
	
	public Defect(int dId, String dCategory, String dDescp, int dPriority, String dStatus) {
		super();
		this.dId = dId;
		this.dCategory = dCategory;
		this.dDescp = dDescp;
		this.dPriority = dPriority;
		this.dStatus = dStatus;
	}


	public int getdId() {
		return dId;
	}

	public void setdId(int dId) {
		this.dId = dId;
	}

	public String getdCategory() {
		return dCategory;
	}

	public void setdCategory(String dCategory) {
		this.dCategory = dCategory;
	}

	public String getdDescp() {
		return dDescp;
	}

	public void setdDescp(String dDescp) {
		this.dDescp = dDescp;
	}

	public int getdPriority() {
		return dPriority;
	}

	public void setdPriority(int dPriority) {
		this.dPriority = dPriority;
	}

	public String getdStatus() {
		return dStatus;
	}

	public void setdStatus(String dStatus) {
		this.dStatus = dStatus;
	}
	
	


}
