package com.infosys.defectmicroservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.defectmicroservice.entity.Defect;

public interface IDefectRepo extends JpaRepository<Defect, Integer> {

}
