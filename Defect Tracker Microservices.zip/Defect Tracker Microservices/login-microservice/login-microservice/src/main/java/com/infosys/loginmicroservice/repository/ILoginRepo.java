package com.infosys.loginmicroservice.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.loginmicroservice.entity.Login;

@Repository
public interface ILoginRepo extends JpaRepository<Login, Integer> {
	
	@Query("select l  from Login l where  l.uname = :uname")
	public Login validateUser(@Param("uname") String uname);

}
