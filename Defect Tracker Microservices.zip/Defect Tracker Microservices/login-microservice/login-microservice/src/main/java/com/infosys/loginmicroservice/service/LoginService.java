package com.infosys.loginmicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.loginmicroservice.entity.Login;
import com.infosys.loginmicroservice.presentation.LoginTO;
import com.infosys.loginmicroservice.repository.ILoginRepo;

@Service
public class LoginService {
	
	@Autowired
	private ILoginRepo repository;

	
	public LoginTO createUser(LoginTO login) {
		// TODO Auto-generated method stub
		Login loginEntity = new Login();
		loginEntity.setUname(login.getUname());
		loginEntity.setPass(login.getPass());
		loginEntity.setRole(login.getRole());
		repository.saveAndFlush(loginEntity);
		login.setuId(loginEntity.getuId());
		return login;
	}
	
	public LoginTO getUserService(int uId) {
		// TODO Auto-generated method stub
		LoginTO login = new LoginTO();
		Login loginEntity = repository.findOne(uId);
		{
			if (loginEntity != null) {
				System.out.println("Fetch the User Successfully");
				login.setuId(loginEntity.getuId());
				login.setPass(loginEntity.getPass());
				login.setUname(loginEntity.getUname());
				login.setRole(loginEntity.getRole());
			} else {
				System.out.println("No Defect Found with ID: " + uId);
			}
		}

		return login;
	}
	
	public LoginTO validateUser(String uname) {
		// TODO Auto-generated method stub
		LoginTO login = new LoginTO();
		Login loginEntity = repository.validateUser(uname);
		{
			if (loginEntity != null) {
				System.out.println("Fetch the User Successfully");
				login.setuId(loginEntity.getuId());
				login.setPass(loginEntity.getPass());
				login.setUname(loginEntity.getUname());
				login.setRole(loginEntity.getRole());
			} else {
				System.out.println("No Defect Found with ID: " + uname);
			}
		}

		return login;
	}
	
	
}
