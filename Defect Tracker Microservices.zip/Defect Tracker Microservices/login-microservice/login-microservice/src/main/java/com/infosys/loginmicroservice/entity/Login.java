package com.infosys.loginmicroservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


	@Entity
	@Table(name = "Login_Table")
	@GenericGenerator(name = "idgen", strategy = "increment")
	public class Login {
			
			@Id
			@GeneratedValue(generator = "idgen")
			private int uId;
			
			private String uname;
			private String pass;
			private String role;
			
			
			public Login() {
				
			}

			public Login(int uId, String uname, String pass, String role) {
				super();
				this.uId = uId;
				this.uname = uname;
				this.pass = pass;
				this.role = role;
			}

			public int getuId() {
				return uId;
			}

			public void setuId(int uId) {
				this.uId = uId;
			}

			public String getUname() {
				return uname;
			}

			public void setUname(String uname) {
				this.uname = uname;
			}

			public String getPass() {
				return pass;
			}

			public void setPass(String pass) {
				this.pass = pass;
			}

			public String getRole() {
				return role;
			}

			public void setRole(String role) {
				this.role = role;
			}
			
			
	}

