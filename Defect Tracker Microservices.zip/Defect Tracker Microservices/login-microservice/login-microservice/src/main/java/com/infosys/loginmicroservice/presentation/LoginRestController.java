package com.infosys.loginmicroservice.presentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.loginmicroservice.service.LoginService;

@RestController
public class LoginRestController {
	
	@Autowired
	private LoginService loginservice;
	
	//@RequestMapping(value = "/login", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/login")
	public ResponseEntity<LoginTO> createUser(@RequestBody LoginTO login) {
		
		login = loginservice.createUser(login);
		
		return new ResponseEntity<LoginTO>(login, HttpStatus.OK);
		
	}
	
	//@RequestMapping(value = "/login", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@GetMapping("/login/{id}")
	public ResponseEntity<LoginTO> getUser(@PathVariable("id") int uid){
			
		LoginTO login = loginservice.getUserService(uid);
		
		return new ResponseEntity<LoginTO>(login, HttpStatus.OK);
	}
	
	//@RequestMapping(value = "/login", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		@GetMapping("/validate/{uname}")
		public ResponseEntity<LoginTO> validateUser(@PathVariable("uname") String uname){
				
			LoginTO login = loginservice.validateUser(uname);
			
			return new ResponseEntity<LoginTO>(login, HttpStatus.OK);
		}

}
