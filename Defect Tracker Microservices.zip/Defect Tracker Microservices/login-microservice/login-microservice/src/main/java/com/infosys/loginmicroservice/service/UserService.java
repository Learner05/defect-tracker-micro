package com.infosys.loginmicroservice.service;

public class UserService {

}
