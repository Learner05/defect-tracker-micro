package com.infosys.loginmicroservice.presentation;

public class LoginTO {

	private int uId;
	
	private String uname;
	private String pass;
	private String role;
	
	
	public LoginTO() {
		
	}

	public LoginTO(int uId, String uname, String pass, String role) {
		super();
		this.uId = uId;
		this.uname = uname;
		this.pass = pass;
		this.role = role;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "LoginTO [uId=" + uId + ", uname=" + uname + ", pass=" + pass + ", role=" + role + "]";
	}
	
}

	
